package orted.imagepro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageProApplicationTests {

	@Test
	void contextLoads() {
	}

}
